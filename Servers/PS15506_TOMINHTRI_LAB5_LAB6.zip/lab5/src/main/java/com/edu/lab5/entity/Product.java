package com.edu.lab5.entity;

import lombok.Data;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import javax.persistence.*;
import java.time.LocalDate;

@Entity
@Data
@Table(name = "Products")
public class Product {
    @Id
    @Column(name = "Id", nullable = false)
    private Integer id;

    @Column(name = "Name", nullable = false, length = 50)
    private String name;

    @Column(name = "Image", nullable = false, length = 50)
    private String image;

    @Column(name = "Price", nullable = false)
    private Double price;

    @Column(name = "CreateDate", nullable = false)
    private LocalDate createDate;

    @Column(name = "Available", nullable = false)
    private Boolean available = false;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @OnDelete(action = OnDeleteAction.CASCADE)
    @JoinColumn(name = "CategoryId", nullable = false)
    private Category category;

}