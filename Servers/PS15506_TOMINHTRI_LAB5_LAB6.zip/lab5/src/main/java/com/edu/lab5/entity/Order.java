package com.edu.lab5.entity;

import lombok.Data;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import javax.persistence.*;
import java.time.Instant;

@Entity
@Data
@Table(name = "Orders")
public class Order {
    @Id
    @Column(name = "Id", nullable = false)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @OnDelete(action = OnDeleteAction.CASCADE)
    @JoinColumn(name = "Username", nullable = false)
    private Account username;

    @Column(name = "CreateDate", nullable = false)
    private Instant createDate;

    @Column(name = "Address", nullable = false, length = 100)
    private String address;



}