package com.edu.lab5.controller;

import com.edu.lab5.entity.Bai2Student;
import com.edu.lab5.repository.Bai2StudentDAO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin("*")
@RestController
public class Bai2StudentRestController {
	@Autowired
	Bai2StudentDAO dao;

	@GetMapping("/rest/students")
	public List<Bai2Student> getAll(ModelMap model) {
		return dao.findAll();
	}

	@GetMapping("/rest/students/{email}")
	public Bai2Student getOne(@PathVariable String email) {
		return dao.findById(email).get();
	}

	@PostMapping("/rest/students")
	public Bai2Student post(@RequestBody Bai2Student student) {
		dao.save(student);
		return student;
	}

	@PutMapping("/rest/students/{email}")
	public Bai2Student put(@PathVariable String email, @RequestBody Bai2Student student) {
		dao.save(student);
		return student;
	}

	@DeleteMapping("/rest/students/{email}")
	public void delete(@PathVariable String email) {
		dao.deleteById(email);
	}

}
