package com.edu.lab5.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.edu.lab5.entity.Bai2Student;

public interface Bai2StudentDAO extends JpaRepository<Bai2Student, String>{

}
