package com.edu.lab5.entity;

import lombok.Data;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Data
@Table(name = "Roles")
public class Role {
    @Id
    @Column(name = "Id", nullable = false, length = 10)
    private String id;

    @Column(name = "Name", nullable = false, length = 50)
    private String name;


}