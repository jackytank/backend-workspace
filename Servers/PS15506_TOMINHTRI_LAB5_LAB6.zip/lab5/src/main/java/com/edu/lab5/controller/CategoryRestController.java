package com.edu.lab5.controller;

import com.edu.lab5.entity.Category;
import com.edu.lab5.repository.CategoryRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin("*")
@RestController
public class CategoryRestController {
    @Autowired
    CategoryRepository repo;

    @GetMapping("/rest/categories")
    public ResponseEntity<List<Category>> getAll() {
        return ResponseEntity.ok(repo.findAll());
    }

    @GetMapping("/rest/categories/{id}")
    public ResponseEntity<Category> getOne(@PathVariable String id) {
        if (!repo.existsById(id)) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(repo.findById(id).get());
    }

    @PostMapping("/rest/categories")
    public ResponseEntity<Category> post(@RequestBody Category category) {
        if (repo.existsById(category.getId())) {
            return ResponseEntity.badRequest().build();
        }
        repo.save(category);
        return ResponseEntity.ok(category);
    }

    @PutMapping("/rest/categories/{id}")
    public ResponseEntity<Category> put(@PathVariable String id, @RequestBody Category category) {
        if (!repo.existsById(id)) {
            return ResponseEntity.notFound().build();
        }
        repo.save(category);
        return ResponseEntity.ok(category);
    }
}
