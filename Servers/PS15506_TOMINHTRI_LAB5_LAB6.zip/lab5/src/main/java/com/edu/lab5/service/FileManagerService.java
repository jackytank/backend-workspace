package com.edu.lab5.service;

import org.springframework.web.multipart.MultipartFile;

import java.nio.file.Path;
import java.util.List;


public interface FileManagerService {

    Path getPath(String folder, String filename);
    byte[] read(String folder, String filename);
    List<String> save(String folder, MultipartFile[] files);
    void delete(String folder, String filename);
    List<String> list(String folder);
}
